package com.rasyidabdulhalim.aquaza.callbacks

import android.view.View
import com.rasyidabdulhalim.aquaza.models.User

interface EmployeCallBack {
    fun onClick(v: View, employee: User)

}
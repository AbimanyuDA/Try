package com.rasyidabdulhalim.aquaza.callbacks

import com.rasyidabdulhalim.aquaza.models.Chat

interface ChatListCallback {

    fun onClick(chat: Chat)
}
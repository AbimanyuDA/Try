# AQUAZA
Aplikasi Pemesanan Air Minum Isi Ulang
![COVER APPLICATION](https://user-images.githubusercontent.com/43528203/141757060-5d8472b6-32ba-4339-b756-dcabc1affb39.png)
![ORDER](https://user-images.githubusercontent.com/43528203/141757180-cfa655f6-55b6-426e-93f4-d26e04248511.png)
![Chat](https://user-images.githubusercontent.com/43528203/141757196-0284a77f-679f-4a0c-9e96-64ce641bdcc5.png)
